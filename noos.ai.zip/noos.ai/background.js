// background.js - Calls REAL backend for verification

// --- Constants ---
// ** REPLACE WITH YOUR ACTUAL CLOUD RUN SERVICE URLS **
const BACKEND_ANALYZE_URL = "https://sentiment-analyzer-service-872183226779.us-central1.run.app/analyze";
const BACKEND_VERIFY_URL = "https://sentiment-analyzer-service-872183226779.us-central1.run.app/verify-license"; // USE THIS NOW

// ** YOUR SHARED SECRET - CHANGE THIS AFTER IT WORKS! **
const EXTENSION_SECRET = "4TheFuture2030@";

const FREE_TIER_LIMIT = 5;

// --- Initialization (Remains the same) ---
chrome.runtime.onInstalled.addListener(() => {
    chrome.storage.sync.set({
        extensionEnabled: true, isPremium: false, totalFreeTierUsageCount: 0,
        enableNegativeAnimation: true, enablePositiveAnimation: true
    });
    console.log("BG: Extension installed/updated. Default settings applied.");
});

// --- Message Listener ---
chrome.runtime.onMessage.addListener(
    function(request, sender, sendResponse) {
        console.log("BG: Received message:", request);

        // --- Handle State Updates (Relay to Content Scripts) ---
        if (request.message === "updateState" || request.message === "updateAnimationSetting") {
            console.log(`BG: Relaying ${request.message} to content scripts.`);
            chrome.tabs.query({}, (tabs) => {
                 if (chrome.runtime.lastError) {
                     console.error("BG: Error querying tabs:", chrome.runtime.lastError); return;
                 }
                tabs.forEach((tab) => {
                    if (tab.id) {
                        chrome.tabs.sendMessage(tab.id, request)
                            .catch(error => {
                                if (!error.message.includes("Could not establish connection") && !error.message.includes("Receiving end does not exist")) {
                                    console.warn(`BG: Error sending message to tab ${tab.id}:`, error.message);
                                }
                            });
                    }
                });
            });
            return false; // Synchronous or no response needed
        }

        // --- Handle REAL License Verification ---
        else if (request.action === "verifyLicenseKey") {
            const key = request.licenseKey;
            console.log(`BG: Received verifyLicenseKey action for key: ${key ? key.substring(0,5) : 'EMPTY'}...`);

            // === REAL BACKEND CALL ===
            console.log("BG: Calling backend to verify license key...");
            fetch(BACKEND_VERIFY_URL, { // Use the correct URL
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-Extension-Secret': EXTENSION_SECRET // Authenticate this request
                },
                body: JSON.stringify({ licenseKey: key })
            })
            .then(response => {
                 console.log(`BG: Verify response status: ${response.status}`);
                 if (!response.ok) {
                      // Try to get error details from backend response body
                      return response.json().then(errData => {
                          // Throw an error with the message from the backend if available
                          throw new Error(errData.message || `Verification failed (${response.status})`);
                      }).catch(() => { // Fallback if body isn't JSON or parsing failed
                           throw new Error(`Verification failed (${response.status} ${response.statusText})`);
                      });
                 }
                 return response.json(); // Expect { valid: true/false, isPremium: true/false, message?: '...' }
            })
            .then(data => { // Handle the JSON data from a successful (2xx) response
                console.log("BG: Received verification data from backend:", data);
                if (data && data.valid === true && data.isPremium === true) { // Check response from backend
                    console.log("BG: Key VALID and PREMIUM per backend. Setting status in storage.");
                    // Set premium AND reset usage count upon successful verification
                    chrome.storage.sync.set({ isPremium: true, totalFreeTierUsageCount: 0 }, () => {
                        if (chrome.runtime.lastError) {
                            console.error("BG: Error setting premium status in storage:", chrome.runtime.lastError.message);
                            sendResponse({ success: false, message: "Storage error after verification" }); // Send specific error back
                        } else {
                            console.log("BG: Premium status saved. Sending success response to popup.");
                            sendResponse({ success: true, isPremium: true }); // Confirm success to popup
                        }
                    });
                } else {
                    // Key is invalid OR backend logic determined user isn't premium for some reason
                    console.log("BG: Key INVALID or not premium according to backend.");
                    sendResponse({ success: false, message: data.message || "Invalid or Inactive Key" }); // Send failure to popup, include backend message if available
                }
            })
            .catch(error => { // Catches network errors or errors thrown in .then() blocks
                console.error("BG: Error during license verification fetch/processing:", error);
                sendResponse({ success: false, message: error.message || "Verification request failed" }); // Send specific error message
            });
            // === END REAL BACKEND CALL ===

            // ** IMPORTANT: Return true because fetch is async and we use sendResponse in its callbacks **
            return true;
        }

        // --- Handle Sentiment Analysis ---
        else if (request.action === "analyzeSentiment") {
            const tabId = sender.tab.id;
            const position = request.position;
            const textToAnalyze = request.text;

            console.log("BG: analyzeSentiment action received.");

            if (!tabId || !position || textToAnalyze === undefined) {
                 console.error("BG: Missing essential data in analyzeSentiment request:", {tabId, position, textToAnalyze});
                 return false; // Cannot proceed
            }

            // Get premium status and usage count
            chrome.storage.sync.get(
                ["isPremium", "totalFreeTierUsageCount"],
                (settings) => { // <--- START of storage.get CALLBACK
                    if (chrome.runtime.lastError) {
                        console.error("BG: Error getting settings:", chrome.runtime.lastError.message);
                        chrome.tabs.sendMessage(tabId, { action: "showSentiment", sentiment: "Error: Could not load settings", score: null, position: position })
                            .catch(e => console.warn("BG: Error sending settings error:", e.message));
                        return; // Exit callback
                    }

                    console.log("BG: Retrieved settings:", settings);
                    const isPremium = settings.isPremium === true;
                    let currentUsageCount = settings.totalFreeTierUsageCount || 0;

                    // Check Free Tier Limit
                    if (!isPremium) { // <--- Start of !isPremium IF block
                        console.log("BG: Checking free tier limit.");
                        if (currentUsageCount >= FREE_TIER_LIMIT) {
                            console.log("BG: Free tier limit reached:", currentUsageCount);
                            chrome.tabs.sendMessage(tabId, { action: "showSentiment", sentiment: "Free tier limit reached. Verify Premium Key!", score: null, position: position })
                                .catch(e => console.warn("BG: Error sending limit message:", e.message));
                            return; // Stop processing THIS REQUEST within the callback if limit reached
                        }
                        // If limit NOT reached, increment and save
                        currentUsageCount++;
                        console.log("BG: Incrementing free tier usage to:", currentUsageCount);
                        chrome.storage.sync.set({ totalFreeTierUsageCount: currentUsageCount }, () => {
                           if(chrome.runtime.lastError) console.error("BG: Error saving usage count:", chrome.runtime.lastError.message);
                           else console.log("BG: Usage count saved.");
                        });
                    } else { // <--- Start of ELSE block (for premium users)
                        console.log("BG: Premium user, proceeding with analysis.");
                        // No tier limit check or count increment needed for premium
                    } // <--- End of if/else (!isPremium) block

                    // --- Call YOUR Backend Service ---
                    // This code runs for premium users OR free users under the limit
                    console.log(`BG: Sending text to backend: "${textToAnalyze ? textToAnalyze.substring(0, 30) : 'EMPTY'}..."`);
                    fetch(BACKEND_ANALYZE_URL, { // Use the correct constant for the analyze endpoint
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-Extension-Secret': EXTENSION_SECRET
                        },
                        body: JSON.stringify({ text: textToAnalyze })
                    })
                    .then(response => {
                        console.log(`BG: Received analyze response status from backend: ${response.status}`);
                        if (!response.ok) {
                            return response.text().then(text => {
                                console.error(`BG: Backend Error (${response.status}): ${text}`);
                                let errorMsg = `Service Error (${response.status})`;
                                try { const errData = JSON.parse(text); errorMsg = `Service Error: ${errData.error || errData.details || response.statusText}`; }
                                catch (e) { errorMsg = `Service Error: ${response.statusText || text.substring(0,100)}`; }
                                throw new Error(errorMsg);
                            });
                        }
                        return response.json();
                    })
                    .then(data => {
                        console.log("BG: Received successful data from backend:", data);
                        if (!data || data.sentiment === undefined ) { // Score can be null
                             console.error("BG: Invalid response format from backend", data);
                             throw new Error("Invalid response from analysis service.");
                        }
                        chrome.tabs.sendMessage(tabId, {
                            action: "showSentiment", sentiment: data.sentiment,
                            score: data.score, position: position
                        }).catch(e => console.warn("BG: Error sending successful sentiment message:", e.message));
                    })
                    .catch(error => {
                        console.error("BG: Error during backend fetch/processing:", error);
                         chrome.tabs.sendMessage(tabId, {
                            action: "showSentiment", sentiment: `Error: ${error.message.substring(0, 60)}...`,
                            score: null, position: position
                        }).catch(e => console.warn("BG: Error sending final error message:", e.message));
                    });
                } // <--- End of settings callback
            ); // <--- End of chrome.storage.sync.get

            // ** IMPORTANT: Return true because storage.get is async **
            return true;
        } // <--- End of analyzeSentiment handler

        // Default if message wasn't handled or was synchronous
        console.warn("BG: Message type not handled or finished synchronously:", request);
        return false;
    }
); // End of onMessage listener