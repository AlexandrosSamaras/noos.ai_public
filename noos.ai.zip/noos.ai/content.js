let tooltip = null;
let hideTimeoutId = null;
const TOOLTIP_FADE_DURATION = 200; // milliseconds
const TOOLTIP_STICK_DURATION = 4000; // Increased stick duration slightly

// Global state variables - initialized via storage
window.extensionEnabled = true;
let allowNegativeAnimation = true;
let allowPositiveAnimation = true;

// Function to load initial state from storage
function initializeExtensionState() {
    chrome.storage.sync.get(
        ['extensionEnabled', 'enableNegativeAnimation', 'enablePositiveAnimation'],
        (data) => {
            if (chrome.runtime.lastError) {
                console.error("Content Script: Error getting initial state:", chrome.runtime.lastError);
            } else {
                window.extensionEnabled = data.extensionEnabled !== false;
                allowNegativeAnimation = data.enableNegativeAnimation !== false;
                allowPositiveAnimation = data.enablePositiveAnimation !== false;
            }
            console.log("Content Script: Initial state loaded:", {
                enabled: window.extensionEnabled,
                negAnim: allowNegativeAnimation,
                posAnim: allowPositiveAnimation
             });
        }
    );
}

initializeExtensionState(); // Load state when script loads

function checkExtentionRunAnalysis() {
    // Directly use the global variable, assuming it's updated by messages
    return window.extensionEnabled;
}

function showTooltip(text, x, y, sentiment, score, isError = false, selectedText) {
  if (!tooltip) {
      tooltip = document.createElement('div');
      tooltip.style.position = 'absolute'; tooltip.style.color = 'black';
      tooltip.style.padding = '8px 10px'; tooltip.style.border = '1px solid #aaa';
      tooltip.style.borderRadius = '5px'; tooltip.style.zIndex = '10000';
      tooltip.style.fontSize = '13px'; tooltip.style.maxWidth = '300px';
      tooltip.style.fontFamily = "Arial, sans-serif";
      tooltip.style.boxShadow = '0 2px 5px rgba(0,0,0,0.15)';
      tooltip.classList.add('sentiment-tooltip', 'fading-in');
      document.body.appendChild(tooltip);
  } else {
    tooltip.classList.remove('fading-out'); tooltip.classList.add('fading-in');
  }

  // Check selectedText *here* before proceeding
  if (!selectedText && text === "Analyzing...") {
       hideTooltip();
       return; // Don't show "Analyzing..." if nothing ended up selected
   }

  let displayText = text;
  if (sentiment && !isError && score !== null && score !== undefined) {
    displayText = `Sentiment: ${sentiment} (${score}%)`;
  } else if (sentiment && !isError) { displayText = `Sentiment: ${sentiment}`; }

  tooltip.textContent = displayText; tooltip.style.left = x + 'px';
  tooltip.style.top = y + 'px'; tooltip.style.display = 'block';

  let bgColor = "rgba(211, 211, 211, 0.7)";
  if (isError) { bgColor = "rgba(255, 182, 193, 0.7)"; }
  else {
    switch (sentiment) {
      case "Positive": bgColor = "rgba(173, 216, 230, 0.7)"; break;
      case "Negative": bgColor = "rgba(240, 128, 128, 0.7)"; break;
      case "Neutral": bgColor = "rgba(255, 255, 255, 0.7)"; break;
    }
  }
  tooltip.style.backgroundColor = bgColor;
  if (hideTimeoutId) { clearTimeout(hideTimeoutId); hideTimeoutId = null; }
}

function hideTooltip() {
    if (tooltip) {
        tooltip.classList.remove('fading-in'); tooltip.classList.add('fading-out');
         hideTimeoutId = setTimeout(()=>{
          if (tooltip) { tooltip.style.display = 'none'; tooltip.classList.remove('fading-out'); }
        }, TOOLTIP_FADE_DURATION);
    }
     if (hideTimeoutId && !tooltip) { clearTimeout(hideTimeoutId); hideTimeoutId = null; }
}


// --- Message Listener ---
chrome.runtime.onMessage.addListener(
    function(request, sender, sendResponse) {
        console.log("Content script received message:", request);

        if (request.message === "updateState") {
          console.log("Updating extensionEnabled state in content script to:", request.enabled);
          window.extensionEnabled = request.enabled; // Update global state
          if (!request.enabled) {
              hideTooltip(); // Hide tooltip immediately if disabled globally
          }
           sendResponse({ received: true });
           return true;

        } else if (request.message === "updateAnimationSetting") {
            console.log("Updating animation setting:", request.setting, "to", request.enabled);
            if (request.setting === "negative") {
                allowNegativeAnimation = request.enabled;
            } else if (request.setting === "positive") {
                allowPositiveAnimation = request.enabled;
            }
            sendResponse({ received: true });
            return true;

        } else if (request.action === "hideTooltip") {
            hideTooltip();
        } else if (request.action === "showSentiment") {
            const isError = request.sentiment?.startsWith("Error:") || request.sentiment === "Parse Error";
            const sentimentLabel = isError ? null : request.sentiment;

            showTooltip( request.sentiment, request.position.x, request.position.y,
                sentimentLabel, request.score, isError, "hasSelectedText" ); // Indicate text selected

            // Conditional Animations
            if (!isError) {
                if (allowNegativeAnimation && sentimentLabel === "Negative") {
                    document.body.classList.add("shake-negative");
                    setTimeout(() => { document.body.classList.remove("shake-negative"); }, 500);
                } else if (allowPositiveAnimation && sentimentLabel === "Positive") {
                    console.log("Positive sentiment - animation enabled.");
                    // Add positive animation trigger here if defined in CSS
                }
            }

            if (hideTimeoutId) { clearTimeout(hideTimeoutId); }
            // Use hideTooltip directly in setTimeout
            hideTimeoutId = setTimeout(hideTooltip, TOOLTIP_STICK_DURATION);
        }
         return false; // Default if not handled or no async response needed
    }
);

// --- Event Listeners ---
document.addEventListener('mouseup', function(event) {
    if (!checkExtentionRunAnalysis()) { return; } // Check global state

    setTimeout(() => {
        const selectedText = window.getSelection()?.toString().trim();
        if (selectedText && selectedText.length > 0) {
            console.log("Text selected, analyzing:", selectedText);
            const x = event.pageX + 5; const y = event.pageY + 5;
            showTooltip("Analyzing...", x, y, null, null, false, selectedText); // Pass selectedText
            chrome.runtime.sendMessage({action: "analyzeSentiment", text: selectedText, position: {x: x, y: y}});
        } else {
             // If selection is empty after delay, hide tooltip
             hideTooltip();
        }
    }, 50); // Delay check
});

document.addEventListener('mousedown', () => {
     // Only hide if the extension is supposed to be active
     if (checkExtentionRunAnalysis()) {
         hideTooltip();
     }
});

// --- CSS Injection ---
const css = `
.sentiment-tooltip { transition: opacity ${TOOLTIP_FADE_DURATION / 1000}s ease-in-out; opacity: 0; }
.fading-in { opacity: 1; } .fading-out { opacity: 0; }
@keyframes shake { 0% { transform: translateX(0); } 25% { transform: translateX(-5px); } 50% { transform: translateX(5px); } 75% { transform: translateX(-5px); } 100% { transform: translateX(0); } }
.shake-negative { animation: shake 0.5s; }
/* @keyframes pulse-subtle { 0% { transform: scale(1); } 50% { transform: scale(1.03); } 100% { transform: scale(1); } } */
/* .pulse-positive { animation: pulse-subtle 1s ease-in-out; } */
`;
const styleElement = document.createElement('style');
styleElement.textContent = css;
document.head.appendChild(styleElement);