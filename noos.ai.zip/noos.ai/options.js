// options.js - Minimal - API Key is server-side now.

document.addEventListener('DOMContentLoaded', () => {
  console.log("Options page loaded.");
  // No options currently configurable via this page.
});