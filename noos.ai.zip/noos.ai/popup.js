document.addEventListener("DOMContentLoaded", () => {
  // Get Elements
  const toggleSwitch = document.getElementById("toggleSwitch");
  const statusLabel = document.querySelector(".status-label");
  const upgradeButton = document.getElementById("upgradeButton");
  const tierInfo = document.getElementById("tierInfo");
  const usageCounter = document.getElementById("usageCounter");
  const negAnimCheckbox = document.getElementById("enableNegativeAnimationPopup");
  const posAnimCheckbox = document.getElementById("enablePositiveAnimationPopup");
  const optionsLink = document.getElementById("openOptionsLink");
  // --- Get License Key Elements ---
  const licenseSection = document.querySelector(".license-section"); // Get the section
  const licenseKeyInput = document.getElementById("licenseKeyInput");
  const verifyLicenseButton = document.getElementById("verifyLicenseButton");
  const licenseStatus = document.getElementById("licenseStatus");

  // State variable
  let isPremium = false;
  const FREE_TIER_LIMIT = 5; // Ensure this matches background.js

  // --- Update Status Label Function ---
  function updateStatusLabel(isEnabled) {
      if (statusLabel) {
          statusLabel.textContent = isEnabled ? "On" : "Off";
      }
  }

  // --- Update Tier and Usage display (Hides/Shows sections) ---
  function updateTierInfo(premiumStatus, count) {
    isPremium = premiumStatus; // Update local state variable
    if (premiumStatus) {
      if (tierInfo) tierInfo.textContent = "Premium Tier"; // Real premium now
      if (usageCounter) usageCounter.textContent = "";
      if (upgradeButton) upgradeButton.style.display = 'none';
      if (licenseSection) licenseSection.classList.add('hidden'); // Hide license section

    } else {
      if (tierInfo) tierInfo.textContent = "Free Tier";
      if (usageCounter) usageCounter.textContent = `Used: ${count} / ${FREE_TIER_LIMIT}`;
      if (upgradeButton) upgradeButton.style.display = 'block';
      if (licenseSection) licenseSection.classList.remove('hidden'); // Show license section
      if (licenseStatus) licenseStatus.textContent = ''; // Clear status on load if free
    }
  }

   // --- Update UI enabled state ---
  function updatePopupUIEnabledState(isEnabled) {
      const elementsToToggle = [negAnimCheckbox, posAnimCheckbox, upgradeButton, optionsLink, licenseKeyInput, verifyLicenseButton];
      const labelsToToggle = document.querySelectorAll('.settings-section .toggle-label-small, .setting-label, #tierInfo, #usageCounter, .license-label'); // Include license label

      elementsToToggle.forEach(el => {
          if(el) {
              // Base disable state on main toggle
              let shouldBeDisabled = !isEnabled;
              // Keep upgrade/license elements enabled if main toggle is on, even if hidden by premium status (their display is handled by updateTierInfo)
              if ((el === upgradeButton || el === licenseKeyInput || el === verifyLicenseButton) && isEnabled) {
                  shouldBeDisabled = false; // Don't disable purely based on isEnabled if hidden later
              }
              el.disabled = shouldBeDisabled;
              el.style.cursor = !shouldBeDisabled ? 'pointer' : 'not-allowed';
          }
      });

       labelsToToggle.forEach(el => {
          if(el) el.style.opacity = isEnabled ? '1' : '0.6';
      });

      // Re-apply display none/block based on premium status AFTER setting enabled/disabled
      updateTierInfo(isPremium, parseInt(usageCounter.textContent.split(' ')[1] || '0') ); // Re-run to ensure visibility is correct
  }

  // --- Load all settings on popup open ---
  chrome.storage.sync.get(
    ["extensionEnabled", "isPremium", "totalFreeTierUsageCount", "enableNegativeAnimation", "enablePositiveAnimation"],
    (data) => {
      if (chrome.runtime.lastError) {
           console.error("Popup: Error loading settings:", chrome.runtime.lastError);
           if(tierInfo) tierInfo.textContent = "Error loading settings";
           return;
      }

      const isEnabled = data.extensionEnabled !== false;
      toggleSwitch.checked = isEnabled;
      updateStatusLabel(isEnabled);

      // Update premium status AND initial UI based on it
      updateTierInfo(data.isPremium === true, data.totalFreeTierUsageCount || 0);

      negAnimCheckbox.checked = data.enableNegativeAnimation !== false;
      posAnimCheckbox.checked = data.enablePositiveAnimation !== false;

      // Set initial UI enabled/disabled state based on main toggle
      updatePopupUIEnabledState(isEnabled);
    }
  );


  // --- Event Listeners ---

  // Main Extension Toggle
  toggleSwitch.addEventListener("change", () => {
    const isEnabled = toggleSwitch.checked;
    updateStatusLabel(isEnabled);

    chrome.storage.sync.set({ extensionEnabled: isEnabled }, () => {
         if (chrome.runtime.lastError) console.error("Popup: Error saving main toggle:", chrome.runtime.lastError);
    });
    sendMessageToContentScripts({ message: "updateState", enabled: isEnabled });
    updatePopupUIEnabledState(isEnabled);
  });

  // Animation Toggles (Remain the same)
  negAnimCheckbox.addEventListener("change", () => {
    const isChecked = negAnimCheckbox.checked;
    chrome.storage.sync.set({ enableNegativeAnimation: isChecked }, () => {
        if (chrome.runtime.lastError) console.error("Popup: Error saving neg anim:", chrome.runtime.lastError);
    });
    sendMessageToContentScripts({ message: "updateAnimationSetting", setting: "negative", enabled: isChecked });
  });
  posAnimCheckbox.addEventListener("change", () => {
    const isChecked = posAnimCheckbox.checked;
    chrome.storage.sync.set({ enablePositiveAnimation: isChecked }, () => {
        if (chrome.runtime.lastError) console.error("Popup: Error saving pos anim:", chrome.runtime.lastError);
    });
    sendMessageToContentScripts({ message: "updateAnimationSetting", setting: "positive", enabled: isChecked });
  });

  // --- MODIFIED Upgrade Button Listener ---
  upgradeButton.addEventListener("click", () => {
    if (toggleSwitch.checked) {
        console.log("Upgrade button clicked. Opening landing page.");
        // ACTION: Open your landing page
        chrome.tabs.create({ url: "https://noosai.co.uk" }); // Use your actual landing page URL
    } else {
        console.log("Upgrade button clicked, but extension is disabled.");
    }
  });
  // --- End MODIFIED Upgrade Button Listener ---

  // --- NEW License Key Verification Listener ---
  if (verifyLicenseButton) {
    verifyLicenseButton.addEventListener("click", () => {
        if (!toggleSwitch.checked) {
             if (licenseStatus) licenseStatus.textContent = "Enable extension first.";
             setTimeout(() => { if (licenseStatus) licenseStatus.textContent = ''; }, 2000);
             return;
        }

        const key = licenseKeyInput ? licenseKeyInput.value.trim() : '';
        if (!key) {
            if (licenseStatus) licenseStatus.textContent = "Please enter a key.";
             if (licenseStatus) licenseStatus.style.color = 'red';
            setTimeout(() => { if (licenseStatus) licenseStatus.textContent = ''; licenseStatus.style.color = 'green'; }, 2000);
            return;
        }

        if (licenseStatus) {
             licenseStatus.textContent = "Verifying...";
             licenseStatus.style.color = '#555'; // Neutral color
        }


        // Send key to background script for verification
        console.log("Popup: Sending verifyLicenseKey message to background with key:", key);
        chrome.runtime.sendMessage({ action: "verifyLicenseKey", licenseKey: key }, (response) => {
            // --- This callback handles the response FROM background.js ---

            if (chrome.runtime.lastError) {
                 console.error("Popup: Error sending/receiving verify message:", chrome.runtime.lastError);
                 if (licenseStatus) {
                    licenseStatus.textContent = "Verification error.";
                    licenseStatus.style.color = 'red';
                 }
                 setTimeout(() => { if (licenseStatus) licenseStatus.textContent = ''; licenseStatus.style.color = 'green'; }, 3000);
                 return;
            }

            console.log("Popup: Received verification response:", response);
            if (response && response.success && response.isPremium) {
                if (licenseStatus) {
                    licenseStatus.textContent = "Premium Activated!";
                    licenseStatus.style.color = 'green';
                }
                // Update UI immediately - fetch updated count just in case
                chrome.storage.sync.get("totalFreeTierUsageCount", (data) => {
                    // Check for errors getting count, although less critical here
                    if(chrome.runtime.lastError) console.warn("Popup: Error getting usage count after activation:", chrome.runtime.lastError);
                    updateTierInfo(true, data.totalFreeTierUsageCount || 0); // Update to show premium
                    updatePopupUIEnabledState(true); // Re-apply enabled state
                });

            } else {
                // Handle specific 'invalid key' response vs other errors if needed
                if (licenseStatus) {
                    licenseStatus.textContent = response.message || "Invalid or inactive key.";
                    licenseStatus.style.color = 'red';
                }
            }
            // Clear status message after a delay
            setTimeout(() => {
                // Only clear if it hasn't been updated again (e.g., by another click)
                 if (licenseStatus && (licenseStatus.textContent === "Premium Activated!" || licenseStatus.textContent === (response.message || "Invalid or inactive key."))) {
                     licenseStatus.textContent = '';
                     licenseStatus.style.color = 'green'; // Reset color
                 }
             }, 4000); // Increased delay
        });
    });
  } else {
      console.warn("License verification button not found in popup.html");
  }
  // --- End License Key Verification Listener ---


  // Options Link (Remains the same)
  optionsLink.addEventListener("click", (event) => {
    event.preventDefault();
    if (chrome.runtime.openOptionsPage) {
      chrome.runtime.openOptionsPage();
    } else {
      window.open(chrome.runtime.getURL('options.html'));
    }
  });

  // Helper function to send messages (Remains the same)
  function sendMessageToContentScripts(message) {
      chrome.tabs.query({}, (tabs) => {
           if (chrome.runtime.lastError) {
                console.error("Popup: Error querying tabs:", chrome.runtime.lastError);
                return;
           }
          tabs.forEach((tab) => {
              if (tab.id) {
                  chrome.tabs.sendMessage(tab.id, message)
                      .catch(error => {
                          if (!error.message.includes("Could not establish connection") && !error.message.includes("Receiving end does not exist")) {
                              console.warn(`Popup: Could not send message to tab ${tab.id}:`, error.message);
                          }
                      });
              }
          });
      });
  }
});